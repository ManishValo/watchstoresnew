function loadAllModels() {
  $.ajax({
    url: 'http://localhost:51851/api/model',
    type: 'GET',
    dataType: 'json',
    success: function (models) {
      let html = `
        <h4>Model List</h4>
        <table class="table table-bordered">
          <thead class="thead-dark">
            <tr>
              <th>Model ID</th>
              <th>Model Name</th>
              <th>Brand Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
      `;

      models.forEach(model => {
        html += `
          <tr>
            <td>${model.ModelId}</td>
            <td>${model.ModelName}</td>
            <td>${model.Brand.BrandName}</td>
            <td>
              <button class="btn btn-sm btn-info" onclick="editModel(${model.ModelId}, '${model.ModelName}', ${model.Brand.BrandId})">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="deleteModel(${model.ModelId})">Delete</button>
            </td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
      $('#modelTableContainer').html(html);
    },
    error: function () {
      alert("Failed to load models.");
    }
  });
}
function loadBrandOptions() {
  $.ajax({
    url: 'http://localhost:51851/api/brand',
    type: 'GET',
    dataType: 'json',
    success: function (brands) {
  console.log("Loaded brands:", brands); // Debug
  const select = $('#brandSelect');
  select.empty();
  select.append('<option value="">-- Select Brand --</option>'); // Optional default
  brands.forEach(b => {
    select.append(`<option value="${b.BrandId}">${b.BrandName}</option>`);
  });
},
  })
}
function submitModel() {
  const modelName = $('#modelNameInput').val().trim();
  const brandId = $('#brandSelect').val();
  const modelId = $('#editingModelId').val();

  if (!modelName || !brandId) {
    alert("Please enter a model name and select a brand.");
    return;
  }

  const payload = {
    ModelName: modelName,
    BrandId: parseInt(brandId)
  };

  if (modelId) {
    // Update
    payload.ModelId = parseInt(modelId);
    $.ajax({
      url: `http://localhost:51851/api/model/${modelId}`,
      type: 'PUT',
      contentType: 'application/json',
      data: JSON.stringify(payload),
      success: function () {
        alert("Model updated successfully.");
        resetModelForm();
        loadAllModels();
      },
      error: function () {
        alert("Failed to update model.");
      }
    });
  } else {
    // Add
    $.ajax({
      url: 'http://localhost:51851/api/model',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(payload),
      success: function () {
        alert("Model added successfully.");
        resetModelForm();
        loadAllModels();
      },
      error: function () {
        alert("Failed to add model.");
      }
    });
  }
}
function editModel(id, name, brandId) {
  $('#modelNameInput').val(name);
  $('#brandSelect').val(brandId);
  $('#editingModelId').val(id);
  $('#modelSubmitBtn').text('Update Model');
}

function deleteModel(id) {
  if (confirm("Are you sure you want to delete this model?")) {
    $.ajax({
      url: `http://localhost:51851/api/model/${id}`,
      type: 'DELETE',
      success: function () {
        alert("Model deleted successfully.");
        loadAllModels();
        resetModelForm();
      },
      error: function () {
        alert("Failed to delete model.");
      }
    });
  }
}

function resetModelForm() {
  $('#modelNameInput').val('');
  $('#editingModelId').val('');
  $('#modelSubmitBtn').text('Add Model');
}
$(document).ready(function () {
  loadAllBrands();
  loadBrandOptions();
  loadAllModels();
});
