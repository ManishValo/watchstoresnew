// 🔁 Load products when "Show Products" clicked
$('#showProductsBtn').on('click', function () {
  loadAllProducts();
});


// 🧾 Load All Products (Read)
function loadAllProducts() {
  $.ajax({
    url: 'http://localhost:51851/api/product',
    type: 'GET',
    dataType: 'json',
    success: function (products) {
      let tableHtml = `
        <h4 class="mt-4">Product List</h4>
        <table class="table table-striped table-bordered mt-3">
          <thead class="thead-dark">
            <tr>
              <th>ID</th>
              <th>Brand</th>
              <th>Model</th>
              <th>Image</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
      `;

      products.forEach(p => {
        const imageUrl = `http://localhost:51851/${p.ProdImg}`;
        tableHtml += `
          <tr>
            <td>${p.ProdID}</td>
            <td>${p.BrandName}</td>
            <td>${p.ModelName}</td>
            <td><img src="${imageUrl}" width="60" height="60" /></td>
            <td>${p.ProdPrice}</td>
            <td>${p.ProdQty}</td>
            <td>${p.ProdDscription}</td>
            <td>
            <button class="btn btn-sm btn-info" onclick="editProduct(${p.ProdID})">Update</button>
            <button class="btn btn-sm btn-danger" onclick="deleteProduct(${p.ProdID})">Delete</button>
           
          </td>
          </tr>
        `;
      });

      tableHtml += `</tbody></table>`;
      $('#productTableContainer').html(tableHtml);
    },
    error: function () {
      alert('Failed to load products.');
    }
  });
}

// 🔄 Load Brand Dropdown
function loadBrands(selectedBrandId = null, callback = null) {
  $.get('http://localhost:51851/api/brand', function (brands) {
    $('#BrandId').empty().append('<option value="">-- Select Brand --</option>');
    brands.forEach(b => {
      const selected = b.BrandId == selectedBrandId ? 'selected' : '';
      $('#BrandId').append(`<option value="${b.BrandId}" ${selected}>${b.BrandName}</option>`);
    });

    if (callback) callback(); // Execute callback after loading
  });
}

// 🔄 Load Model Dropdown by Brand
function loadModelsForBrand(brandId, selectedModelId = null) {
  if (!brandId) return;

  $.ajax({
    url: `http://localhost:51851/api/model/brand/${brandId}`,
    type: 'GET',
    success: function (models) {
      let modelOptions = '<option value="">Select Model</option>';
      models.forEach(model => {
        const selected = model.ModelId == selectedModelId ? 'selected' : '';
        modelOptions += `<option value="${model.ModelId}" ${selected}>${model.ModelName}</option>`;
      });
      $('#ModelId').html(modelOptions);
    },
    error: function () {
      alert('Failed to load models');
    }
  });
}

// ⬇ On Brand Change, Load Models
$(document).on('change', '#BrandId', function () {
  const brandId = $(this).val();
  loadModelsForBrand(brandId);
});

// ✏️ Edit Product (Fill Form)
function editProduct(prodId) {
  $.ajax({
    url: `http://localhost:51851/api/product/${prodId}`,
    type: 'GET',
    success: function (product) {
      const formHtml = `
       <form id="productForm" class="mt-4" data-prod-id="${product.ProdID}" enctype="multipart/form-data">

          <table class="table table-bordered">
            <tbody>
          <table class="table table-bordered">
            <tbody>
              <tr>
                <th><label for="BrandId">Select Brand</label></th>
                <td><select id="BrandId" class="form-control" required></select></td>
              </tr>
              <tr>
                <th><label for="ModelId">Select Model</label></th>
                <td><select id="ModelId" class="form-control" name="ModelId"  required></select></td>
              </tr>
              <tr>
                <th><label for="ProdImg">Upload Image</label></th>
                <td><input type="file" class="form-control" id="ProdImg"  name="ProdImg"  accept="image/*"></td>
              </tr>
              <tr>
                <th><label for="ProdPrice">Price</label></th>
                <td><input type="number" step="0.01" id="ProdPrice" name="ProdPrice" class="form-control" value="${product.ProdPrice}" required></td>
              </tr>
              <tr>
                <th><label for="ProdQty">Quantity</label></th>
                <td><input type="number" id="ProdQty" class="form-control" name="ProdQty" value="${product.ProdQty}" required></td>
              </tr>
              <tr>
                <th><label for="ProdDscription">Description</label></th>
                <td><textarea id="ProdDscription" class="form-control"  name="ProdDscription" rows="3" required>${product.ProdDscription}</textarea></td>
              </tr>
            </tbody>
          </table>
          <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
      `;
      $('#formContainer').html(formHtml).show();

      loadBrands(product.BrandId, () => {
        loadModelsForBrand(product.BrandId, product.ModelId);
      });
    }
  });
}

$(document).on('submit', '#productForm', function (e) {
  e.preventDefault(); // Prevent full page reload

  const form = document.getElementById('productForm');
  const prodId = $('#productForm').data('prod-id');
  const formData = new FormData(form);

  $.ajax({
    url: `http://localhost:51851/api/product/upload/${prodId}`,
    type: 'PUT',  // If PUT gives issues, test with 'POST' and update Web API
    data: formData,
    contentType: false,
    processData: false,
    success: function () {
      alert('Product updated successfully.');
      $('#formContainer').hide().empty();
      loadAllProducts(); // Refresh product list
    },
    error: function (xhr) {
      alert('Upload failed:\n' + xhr.responseText);
    }
  });
});



function showAddProductForm() {
  const formHtml = `
    <form id="addProductForm" class="mt-4">
      <table class="table table-bordered">
        <tbody>
          <tr>
            <th><label for="ModelIds">Model Id</label></th>
            <td><input type="hidden" id="ModelId" name="ModelId" value="" /></td>
          </tr>
          <tr>
            <th><label for="BrandName">Brand Name</label></th>
            <td><input type="text" id="BrandName" class="form-control" required></td>
          </tr>
          <tr>
            <th><label for="ModelName">Model Name</label></th>
            <td><input type="text" id="ModelName" class="form-control" required></td>
          </tr>
          <tr>
            <th><label for="ProdImg">Upload Image</label></th>
            <td><input type="file" class="form-control" id="ProdImg" accept="image/*" required></td>
          </tr>
          <tr>
            <th><label for="ProdPrice">Price</label></th>
            <td><input type="number" step="0.01" id="ProdPrice" class="form-control" required></td>
          </tr>
          <tr>
            <th><label for="ProdQty">Quantity</label></th>
            <td><input type="number" id="ProdQty" class="form-control" required></td>
          </tr>
          <tr>
            <th><label for="ProdDscription">Description</label></th>
            <td><textarea id="ProdDscription" class="form-control" rows="3" required></textarea></td>
          </tr>
        </tbody>
      </table>
      <button type="submit" class="btn btn-primary">Add Product</button>
    </form>
  `;

  $('#formContainer').html(formHtml).show();
}
$(document).on('submit', '#addProductForm', function(e) {
  e.preventDefault();

  const modelId = $('#ModelId').val(); // ← Add this
  const brandName = $('#BrandName').val();
  const modelName = $('#ModelName').val();
  const prodPrice = parseFloat($('#ProdPrice').val());
  const prodQty = parseInt($('#ProdQty').val());
  const prodDscription = $('#ProdDscription').val();
  const prodImgFile = $('#ProdImg')[0].files[0];

  if (!prodImgFile) {
    alert('Please select an image.');
    return;
  }

  const formData = new FormData();
  formData.append('ModelId', modelId); // ← Append it!
  formData.append('BrandName', brandName);
  formData.append('ModelName', modelName);
  formData.append('ProdPrice', prodPrice);
  formData.append('ProdQty', prodQty);
  formData.append('ProdDscription', prodDscription);
  formData.append('ProdImg', prodImgFile);

  $.ajax({
    url: 'http://localhost:51851/api/product/upload',
    type: 'POST',
    data: formData,
    processData: false,
    contentType: false,
    success: function() {
      alert('Product added successfully!');
      $('#formContainer').hide().empty();
      loadAllProducts();
    },
    error: function(xhr) {
      alert('Failed to add product. ' + xhr.responseText);
    }
  });
});

function deleteProduct(productId) {
  if (!confirm("Are you sure you want to delete this product?")) return;

  $.ajax({
    url: `http://localhost:51851/api/product/${productId}`,
    type: 'DELETE',
    success: function () {
      alert("Product deleted successfully.");
      loadAllProducts(); // Refresh the product list
    },
    error: function () {
      alert("Failed to delete product.");
    }
  });
}





























//   function loadCategories() {
//     $.ajax({
//       url: "http://localhost:50431/api/category",
//       method: "GET",
//       success: function (data) {
//         let rows = '';
//         data.forEach(function (cat) {
//           rows += `<tr>
//                      <td><input type="radio" name="categorySelect" value="${cat.categoryId}" data-name="${cat.categoryName}" /></td>
//                      <td>${cat.categoryId}</td>
//                      <td>${cat.categoryName}</td>
//                    </tr>`;
//         });
//         $('#categoryTable tbody').html(rows);
//       }
//     });
//   }
// //Load models based on selected brand
// function loadModelsByBrand(brandId) {
//   $.get(`http://localhost:51851/api/models/bybrand/${brandId}`, function (models) {
//     $('#ModelId').empty().append('<option value="">-- Select Model --</option>');
//     models.forEach(m => {
//       $('#ModelId').append(`<option value="${m.ModelId}">${m.ModelName}</option>`);
//     });
//   });
// }

// // Call this after rendering the form
// $("#product-link").click(loadBrands)
// // loadBrands();

// // On brand change, load models for that brand
// $(document).on('change', '#BrandId', function () {
//   const brandId = $(this).val();
//   if (brandId) {
//     loadModelsByBrand(brandId); 
//   } else {
//     $('#ModelId').html('<option value="">-- Select Model --</option>');
//   }
// });





    // function getProductById(prodId) {
    //     $.ajax({
    //         type: "GET",
    //         url: `http://localhost:51851/api/products/${prodId}`,
    //         success: function (response) {
    //             console.log("Product data:", response);
    //             // Example of displaying it in the UI
    //             $('#prodDetails').html(`
    //                 <p><strong>ID:</strong> ${response.ProdID}</p>
    //                 <p><strong>Price:</strong> $${response.ProdPrice}</p>
    //                 <p><strong>Description:</strong> ${response.ProdDscription}</p>
    //                 <p><strong>Quantity:</strong> ${response.ProdQty}</p>
    //                 <p><strong>Model ID:</strong> ${response.ModelId}</p>
    //                 <img src="${response.ProdImg}" alt="Product Image" style="max-width:200px;">
    //             `);
    //         },
    //         error: function (err) {
    //             alert("Failed to fetch product");
    //             console.log(err);
    //         }
    //     });
    // }

    // // Example: call this function on button click or page load
    // $(document).ready(function () {
    //     getProductById(1); // Replace 1 with the actual product ID
    // });


   
// if (id === "product-link") {
//   $('#productForm').submit(function (e) {
//     e.preventDefault();

//     const productData = {
//       ProdPrice: parseFloat($('#ProdPrice').val()),
//       ProdImg: $('#ProdImg').val(),
//       ProdDscription: $('#ProdDscription').val(),
//       ProdQty: parseInt($('#ProdQty').val()),
//       ModelId: parseInt($('#ModelId').val())
//     };

//     $.ajax({
//       url: 'http://localhost:51851/api/products', // Adjust API endpoint as needed
//       type: 'POST',
//       contentType: 'application/json',
//       data: JSON.stringify(productData),
//       success: function () {
//         alert('Product added successfully!');
//         $('#productForm')[0].reset();
//       },
//       error: function (xhr) {
//         alert('Error adding product');
//         console.error(xhr);
//       }
//     });
//   });
// }
