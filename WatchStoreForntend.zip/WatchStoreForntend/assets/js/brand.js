function loadAllBrands() {
  $.ajax({
    url: 'http://localhost:51851/api/brand',
    type: 'GET',
    dataType: 'json',
    success: function (brands) {
      let html = `
        <h4>Brand List</h4>
        <table class="table table-bordered">
          <thead class="thead-dark">
            <tr>
              <th>Brand ID</th>
              <th>Brand Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
      `;

      brands.forEach(brand => {
        html += `
          <tr>
            <td>${brand.BrandId}</td>
            <td>${brand.BrandName}</td>
            <td>
              <button class="btn btn-sm btn-info" onclick="editBrand(${brand.BrandId}, '${brand.BrandName}')">Edit</button>
              <button class="btn btn-sm btn-danger" onclick="deleteBrand(${brand.BrandId})">Delete</button>
            </td>
          </tr>
        `;
      });

      html += `</tbody></table>`;
      $('#brandTableContainer').html(html);
    },
    error: function () {
      alert("Failed to load brands.");
    }
  });
}

function submitBrand() {
  const brandName = $('#brandNameInput').val().trim();
  const brandId = $('#editingBrandId').val();

  if (!brandName) {
    alert("Please enter a brand name.");
    return;
  }

  if (brandId) {
    // Update
    $.ajax({
      url: `http://localhost:51851/api/brand/${brandId}`,
      type: 'PUT',
      contentType: 'application/json',
      data: JSON.stringify({ BrandId: parseInt(brandId), BrandName: brandName }),
      success: function () {
        alert("Brand updated successfully.");
        resetBrandForm();
        loadAllBrands();
      },
      error: function () {
        alert("Failed to update brand.");
      }
    });
  } else {
    // Add new
    $.ajax({
      url: 'http://localhost:51851/api/brand',
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ BrandName: brandName }),
      success: function () {
        alert("Brand added successfully.");
        resetBrandForm();
        loadAllBrands();
      },
      error: function () {
        alert("Failed to add brand.");
      }
    });
  }
}

function editBrand(id, name) {
  $('#brandNameInput').val(name);
  $('#editingBrandId').val(id);
  $('#brandSubmitBtn').text('Update Brand');
}

function deleteBrand(id) {
  if (confirm("Are you sure you want to delete this brand?")) {
    $.ajax({
      url: `http://localhost:51851/api/brand/${id}`,
      type: 'DELETE',
      success: function () {
        alert("Brand deleted successfully.");
        loadAllBrands();
        resetBrandForm();
      },
      error: function () {
        alert("Failed to delete brand.");
      }
    });
  }
}

function resetBrandForm() {
  $('#brandNameInput').val('');
  $('#editingBrandId').val('');
  $('#brandSubmitBtn').text('Add Brand');
}

$(document).ready(function () {
  loadAllBrands();
});
