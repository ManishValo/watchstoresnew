if (id === 'customer-link') {
  $('#showCustomersBtn').on('click', function () {
    loadAllCustomers();
  });
}
function loadAllCustomers() {
  $.ajax({
    url: 'http://localhost:51851/api/customer', // Adjust this if your route is different
    type: 'GET',
    dataType: 'json',
    success: function (customers) {
      let tableHtml = `
        <h4 class="mt-4">Customer List</h4>
        <table class="table table-bordered table-striped">
          <thead class="thead-dark">
            <tr>
              <th>CustID</th>
              <th>Shipping Address</th>
              <th>User Name</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
      `;

      customers.forEach(c => {
        tableHtml += `
          <tr>
            <td>${c.CustID}</td>
            <td>${c.ShippingAddressLine1}</td>
            <td>${c.UserDetails.UserName}</td>
            <td>${c.UserDetails.Email}</td>
            <td>
              <button class="btn btn-sm btn-info" onclick="editCustomer(${c.CustID})">Update</button>
              <button class="btn btn-sm btn-danger" onclick="deleteCustomer(${c.CustID})">Delete</button>
            </td>
          </tr>
        `;
      });

      tableHtml += `</tbody></table>`;
      $('#customerTableContainer').html(tableHtml);
    },
    error: function () {
      alert('Failed to load customers.');
    }
  });
}
