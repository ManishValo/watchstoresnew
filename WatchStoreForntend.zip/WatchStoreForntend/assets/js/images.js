document.addEventListener('DOMContentLoaded', () => {
  fetch('http://localhost:51851/api/product')
    .then(response => response.json())
    .then(products => {
      const featuredContainer = document.getElementById('featured-container');
      let featuredHTML = '';

      // Filter products by BrandId == 3 (Cartier)
      const filteredProducts = products.filter(product => product.BrandName.toLowerCase() === 'cartier');

      
      filteredProducts.forEach(product => {
        featuredHTML += `
          <article class="products__card">
            <div class="products__box">
              <img src="http://localhost:51851/${product.ProdImg}"  ${product.ModelName}" class="products__img">
            </div>
            <h3 class="products__title">${product.ModelName}</h3>
            <span class="products__price">$${product.ProdPrice}</span>
            <button class="products__button" onclick="addToCart(${product.ProdID})">
              <i class='bx bx-shopping-bag'></i>
            </button>
          </article>
        `;
      });

      featuredContainer.innerHTML = featuredHTML;
    })
    .catch(error => console.error('Error loading featured products:', error));
});

document.addEventListener('DOMContentLoaded', () => {
  fetch('http://localhost:51851/api/product')
    .then(response => response.json())
    .then(products => {
      const featuredContainer = document.getElementById('products-container'); // Select your container div by class
      let featuredHTML = '';

      // Filter products where BrandName exactly equals "OmegaAqua Terra"
      const filteredProducts = products.filter(product => product.BrandName === 'OmegaAqua Terra');

      filteredProducts.forEach(product => {
        featuredHTML += `
          <article class="products__card">
            <div class="products__box">
              <img src="http://localhost:51851/${product.ProdImg}" alt="${product.ModelName}" class="products__img">
            </div>
            <h3 class="products__title">${product.ModelName}</h3>
            <span class="products__price">$${product.ProdPrice}</span>
            <button class="products__button" onclick="addToCart(${product.ProdID})">
              <button class="products__button" onclick="addToCart(${product.ProdID}, '${product.ModelName}', ${product.ProdPrice}, '${product.ProdImg}',${product.prodQty})">
                <i class='bx bx-shopping-bag'></i>
              </button>

            </button>
          </article>
        `;
      });

      featuredContainer.innerHTML = featuredHTML;
    })
    .catch(error => console.error('Error loading featured products:', error));
});

// 🛒 Global cart object
const cart = {};

document.addEventListener('DOMContentLoaded', () => {
  // Attach listeners to all add-to-cart buttons
  document.querySelectorAll('.add-to-cart-btn').forEach(button => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');
      const title = button.getAttribute('data-title');
      const price = parseFloat(button.getAttribute('data-price'));
      const image = button.getAttribute('data-image');
      const prodQty = parseInt(button.getAttribute('data-prodqty'));

      addToCart(id, title, price, image, prodQty);
    });
  });
});
// ✅ Add to Cart function with stock check
function addToCart(id, title, price, image, prodQty) {
  if (cart[id]) {
    if (cart[id].quantity < cart[id].prodQty) {
      cart[id].quantity += 1;
    } else {
      alert(`You cannot add more than ${cart[id].prodQty} items.`);
    }
  } else {
    cart[id] = {
      id,
      title,
      price,
      image,
      prodQty, // stock from backend
      quantity: 1
    };
  }

  // Update cart count
  document.getElementById('cart-count').textContent = Object.values(cart).reduce(
    (sum, item) => sum + item.quantity, 0
  );

  renderCart();
}

// ✅ Render Cart
function renderCart() {
  const cartContainer = document.querySelector('.cart__container');
  cartContainer.innerHTML = ''; // Clear existing cart content

  let totalPrice = 0;

  for (const id in cart) {
    const item = cart[id];
    totalPrice += item.price * item.quantity;

    const cartItem = document.createElement('div');
    cartItem.classList.add('cart__item');

    const isOverstock = item.quantity >= item.prodQty;

    cartItem.innerHTML = `
      <div class="cart__box">
        <img src="http://localhost:51851/${item.image}" alt="${item.title}" class="cart__img">
        <div class="cart__details">
          <h3 class="cart__title">${item.title}</h3>
          <span class="cart__price">$${item.price}</span>
          <div class="cart__amount">
            <button class="cart__amount-box decrease" data-id="${id}">-</button>
            <span>${item.quantity}</span>
            <button class="cart__amount-box increase" data-id="${id}">+</button>
            ${isOverstock ? `<span class="quantity-warning" style="color:red; font-size:12px; margin-left:10px;">Max stock reached</span>` : ''}
          </div>
        </div>
      </div>
      <span class="cart__item-total">$${(item.price * item.quantity).toFixed(2)}</span>
      <i class="bx bx-trash cart__amount-trash" data-id="${id}"></i>
    `;

    cartContainer.appendChild(cartItem);
  }

  document.getElementById('cart-total-price').textContent = `$${totalPrice.toFixed(2)}`;

  // Event handlers
  document.querySelectorAll('.increase').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.getAttribute('data-id');
      if (cart[id].quantity < cart[id].prodQty) {
        cart[id].quantity++;
      } else {
        alert(`You cannot add more than ${cart[id].prodQty} items.`);
      }
      renderCart();
    });
  });

  document.querySelectorAll('.decrease').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.getAttribute('data-id');
      if (cart[id].quantity > 1) {
        cart[id].quantity--;
      } else {
        delete cart[id];
      }
      renderCart();
    });
  });

  document.querySelectorAll('.cart__amount-trash').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.getAttribute('data-id');
      delete cart[id];
      renderCart();
    });
  });
}

// ✅ Show/hide cart
document.addEventListener('DOMContentLoaded', () => {
  const cartShop = document.getElementById('cart-shop');
  const cartElement = document.getElementById('cart');
  const cartClose = document.getElementById('cart-close');

  cartShop.addEventListener('click', () => {
    cartElement.classList.add('show-cart');
  });

  cartClose.addEventListener('click', () => {
    cartElement.classList.remove('show-cart');
  });
});
