 
 $('#loginform').submit(function (e) {
                e.preventDefault(); // prevent default form submit

                var email = $('#email').val();
                var password = $('#Password').val();
                console.log(email,password)

                $.ajax({
                    type: "POST",
                    url: "http://localhost:51851/api/userdetails/login", // Adjust this to your API endpoint
                    data: { "Email": email, "Password": password },
                    success: function (response) {
                        console.log(response)
                        if (response && response.TypeId === 1) {
                            // Redirect to admin dashboard
                            window.location.href = "admindashboard.html";
                        } else if (response && response.TypeId === 2) {
                            window.location.href = "index.html"; // User redirect
                        } else {
                            alert("Invalid login or not an admin");
                        }
                    },
                    error: function (err) {
                        alert("Login failed");
                        console.log(err);
                    }
                });
            });